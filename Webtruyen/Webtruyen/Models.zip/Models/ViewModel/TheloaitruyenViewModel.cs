﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.ViewModel
{
    public class TheloaitruyenViewModel
    {
        public int Matheloai { get; set; }       
        public string Tentheloai { get; set; }

        public int Matruyentl { get; set; }

        public int? Matruyen { get; set; }
    }
}
