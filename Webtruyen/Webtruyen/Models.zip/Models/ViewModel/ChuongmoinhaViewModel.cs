﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.ViewModel
{
    class Chuongmoinhat
    {
        public int Matruyen { get; set; }
        public string Tentruyen { get; set; }
        public string Tacgia { get; set; }
       
        public int? Sochuong { get; set; }
        public string Anhbia { get; set; }
        public string Tinhtrang { get; set; }
        public int? Thutuchuong { get; set; }
        public int? Solandoc { get; set; }
        public int Machuong { get; set; }

        
       
        public string Tenchuong { get; set; }

       
        
        
        public DateTime? Capnhatchuong { get; set; }
    }
}
