﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.ViewModel
{
    class TruyentheotheloaiViewModel
    {
    
        public int Matruyen { get; set; }
        public string Tentruyen { get; set; }
        public string Tacgia { get; set; }
        public int? Maloai { get; set; }
        public string Mota { get; set; }
        public int? Sochuong { get; set; }
        public string Anhbia { get; set; }
        public DateTime? Ngaycapnhat { get; set; }
       

        public string Nguon { get; set; }
        public string Tinhtrang { get; set; }
        public int? Solandoc { get; set; }
        public int? Matheloai { get; set; }
        public string Tentheloai { get; set; }
    }
}
